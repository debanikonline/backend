module.exports={
    database:{
        "connectionString":"mongodb://localhost/mydb"
    }
}